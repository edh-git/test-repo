<?php

//////////////////////////////////////////////////////////////////////////////////////////
// XML 기본 정보 - Configuration
// 참고: Twomon과 EasyBee의 XML 구조가 다르므로, 이에 준하여 URL을 얻는 함수도 각각 구성.
//       EasyCanvas의 XML 구조는 Twomon에 준한다고 정의.
$productXmlInfo = array(
	'Twomon_Windows'=>array('targetProduct'=>'Twomon', 'targetXml'=>'http://www.easynlight.com/product/twomon/binary/pineapple/Twomon_PC_Program_Update_Info_New.xml', 'targetOS'=>'windows'),
	'Twomon_Mac'=>array('targetProduct'=>'Twomon', 'targetXml'=>'http://www.easynlight.com/product/twomon/binary/pineapple/Twomon_PC_Program_Update_Info_New.xml', 'targetOS'=>'macosx'),
	'Twomon_Mac_higher'=>array('targetProduct'=>'Twomon', 'targetXml'=>'http://www.easynlight.com/product/twomon/binary/pineapple/Twomon_PC_Program_Update_Info_New.xml', 'targetOS'=>'macosx_higher'),
	'EasyBee_Windows'=>array('targetProduct'=>'EasyBee', 'targetXml'=>'http://www.easynlight.com/product/easyi/binary/easybee_recent_version_info.xml', 'targetOS'=>'windows'),
	'EasyBee_Mac'=>array('targetProduct'=>'EasyBee', 'targetXml'=>'http://www.easynlight.com/product/easyi/binary/easybee_recent_version_info.xml', 'targetOS'=>'macosx'),
	'EasyCanvas_Windows'=>array('targetProduct'=>'EasyCanvas', 'targetXml'=>'http://www.easynlight.com/product/easycanvas/binary/EasyCanvas_PC_Program_Update_Info.xml', 'targetOS'=>'windows'),
	'EasyCanvas_Mac'=>array('targetProduct'=>'EasyCanvas', 'targetXml'=>'http://www.easynlight.com/product/easycanvas/binary/EasyCanvas_PC_Program_Update_Info.xml', 'targetOS'=>'macosx'),
	'TwomonSE_Windows'=>array('targetProduct'=>'TwomonSE', 'targetXml'=>'http://www.easynlight.com/product/twomonse/binary/twomonse_pc_program_update_info.xml', 'targetOS'=>'windows'),
	'EasyCanvasPro_Windows'=>array('targetProduct'=>'EasyCanvas_Pro', 'targetXml'=>'http://www.easynlight.com/product/easycanvas_pro/binary/EasyCanvas_Pro_PC_Program_Update_Info.xml','targetOS'=>'windows'));
//  'product parameter' => 'Kind of product',         'XML for relese',                                                                                                'Kind of OS'
//////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
// EasyBee Configuration
require_once("./elconfig.php");
//////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
// 사용자 및 Browser 정보 확인을 위한 Class
require_once("./PhpUserAgent/UserAgentParser.php");
//////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
// 사용자 접속 IP Address 확인을 위한 함수
function getRealIpAddr()
{
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) 			//check ip from share internet
	{
        $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))	//to check ip is pass from proxy
    {
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
        $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// 배포용 XML에서 Download URL을 가져온다.
// Twomon(XML)과 EasyBee(PLIST)의 XML 구조가 다르므로, 이에 준하여 URL을 얻는 함수도 각각 구성.
// EasyCanvas의 XML 구조는 Twomon에 준한다고 정의.
function getDownloadUrl($targetProduct, $targetXml, $targetOS)
{
	$info[0] = $info[1] = $info[2] = null;

	$response = file_get_contents($targetXml);	// Contents 가져오기
	if (FALSE === $response)
	{
		return null;		// contents를 가져올 수 없음.
	}
	$xmlContents = simplexml_load_string($response);	// xml 정보로 구성

	if ('Twomon' == $targetProduct)			// Twomon인 경우에 대한 처리 (XML)
	{
		$countInfo = count($xmlContents->info);

		for ($index=0;$index<$countInfo;$index++)
		{
			$osValue = $xmlContents->info[$index]['OSName'];
			if ($osValue == $targetOS)
			{
				$info[0] = $xmlContents->info[$index]->osVerOver[0]->location;
				$info[1] = $xmlContents->info[$index]->osVerOver[0]->version;
				$info[2] = $info[0];
				break;
			}
		}
	}
	elseif ('EasyBee' == $targetProduct)	// EasyBee인 경우에 대한 처리 (PLIST)
	{
		$plist = array();
		$key = null;
		$value = null;

		foreach ($xmlContents->dict->children() as $child)
		{
			if ('key' == $child->getname())
			{
				$key = (string)$child;
			}
			elseif (!is_null($key))
			{
				$value = (string)$child;
				if (empty($value))
				{
					$value = $child->getName();
				}
			}

			if (!is_null($key) &&  !is_null($value))
			{
				$plist[$key] = $value;
				$key = null;
				$value = null;
			}
		}

		if ('windows' == $targetOS)
		{
			$info[0] = $plist['download_address_win'];
			$info[1] = $plist['version_win'];
		}
		elseif ('macosx' == $targetOS)
		{
			$info[0] = $plist['download_address'];
			$info[1] = $plist['version'];
		}
		$info[2] = $info[0];

		/*
		$info[0] = $xmlContents->dict->string[1];
		$info[1] = $xmlContents->dict->string[0];
		$info[2] = $info[0];
		*/
	}
	elseif ('EasyCanvas' == $targetProduct)	// EasyCanvas 경우에 대한 처리 (Twomon Style)
	{
		$EasyCanvasInfo = $xmlContents->twomon_update_info;

		$countInfo = count($EasyCanvasInfo->info);

		for ($index=0;$index<$countInfo;$index++)
		{
			$osValue = $EasyCanvasInfo->info[$index]['os'];
			if ($osValue == $targetOS)
			{
				$info[0] = $EasyCanvasInfo->info[$index]->os_version->package->location;
				$info[1] = $EasyCanvasInfo->info[$index]->os_version->package->version;
				$info[2] = $info[0];
				break;
			}
		}
	}
	elseif ('EasyCanvas_Pro' == $targetProduct)	// EasyCanvas_Pro 경우에 대한 처리 (Twomon Style)
	{
		$EasyCanvasInfo = $xmlContents->twomon_update_info;

		$countInfo = count($EasyCanvasInfo->info);

		for ($index=0;$index<$countInfo;$index++)
		{
			$osValue = $EasyCanvasInfo->info[$index]['os'];
			if ($osValue == $targetOS)
			{
				$info[0] = $EasyCanvasInfo->info[$index]->os_version->package->location;
				$info[1] = $EasyCanvasInfo->info[$index]->os_version->package->version;
				$info[2] = $info[0];
				break;
			}
		}
	}
	elseif ('TwomonSE' == $targetProduct)	// TwomonSE 경우에 대한 처리 (EasyCanvas와 동일한 구조)
	{
		$TwomonSEInfo = $xmlContents->twomon_update_info;

		$countInfo = count($TwomonSEInfo->info);

		for ($index=0;$index<$countInfo;$index++)
		{
			$osValue = $TwomonSEInfo->info[$index]['os'];
			if ($osValue == $targetOS)
			{
				$info[0] = $TwomonSEInfo->info[$index]->os_version->package->location;
				$info[1] = $TwomonSEInfo->info[$index]->os_version->package->version;
				$info[2] = $info[0];
				break;
			}
		}
	}

	return $info;
}
//////////////////////////////////////////////////////////////////////////////////////

// Step1. Paremter와 Configration 점검
$productName = null;	// 다운로드 받고자 하는 Product이름.
// 다운로드 할 제품 종류
if (isset($_GET['product']))
{
	$productName = $_GET['product'];
}
else
{
	// Invalid parameters, Download failed -> Go Home
	echo "<script> window.location.replace('/'); </script>";
	exit();
}

$keyProductName = null;	// Product Name (internal)
$keyXmlUrl = null;		// Product 업데이트 정보를 담은 XML URL
$keyOS = null;			// 점검하려는 OS 버전

// 다운로드 정보를 확인할 XML 경로
if (isset($productXmlInfo[$productName]) && isset($productXmlInfo[$productName]['targetXml']) && isset($productXmlInfo[$productName]['targetOS']))
{
	$keyProductName = $productXmlInfo[$productName]['targetProduct'];
	$keyXmlUrl = $productXmlInfo[$productName]['targetXml'];
	$keyOS = $productXmlInfo[$productName]['targetOS'];
}
else
{
	// Invalid parameters/configuration, Download failed -> Go Home.
	echo "<script> window.location.replace('/'); </script>";
	exit();
}


// Step2. download binary URL 가져오기
$productBinaryUrl = null;	// 바이너리 배포파일 다운로드 URL
$binaryVersion = null;		// 바이너리 파일 버전
$binaryName = null;			// 바이너리 파일 이름

$downloadInfo = getDownloadUrl($keyProductName, $keyXmlUrl, $keyOS);
if (null != $downloadInfo)
{
	$productBinaryUrl = $downloadInfo[0];
	$binaryVersion = $downloadInfo[1];
	$binaryName = $downloadInfo[2];
}

//Testing
//echo "$productBinaryUrl  ,  $binaryVersion  ,  $binaryName";
//exit();

if (null != $productBinaryUrl && false == empty($productBinaryUrl))
{
	// Step3. Download 관련 정보를 DB에 추가 (필요할 경우)
	if ('EasyBee' == $keyProductName)	// EasyBee일 경우에만 DB에 정보기록
	{
		$userlocale = "N/A";
		if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE']))
		{
			$userlocale = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
		}
		$ua_info = parse_user_agent();
		$uaFullInfo = $ua_info['platform']."-".$ua_info['browser']."(".$ua_info['version'].")";
		$userAddr = getRealIpAddr();
		$regist_day = date("Y-m-d (H:i:s)");

		// DB Insert
/*
	create table eldownload (download_date timestamp default now(), product_name varchar(32), product_version varchar(32), product_binary varchar(255), user_addr varchar(40), user_locale varchar(8), user_agent varchar(128))
*/
		$conn = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
		$dbconn = mysql_select_db(DB_NAME, $conn);

		if ($dbconn)
		{
			$query = "insert into eldownload (download_date, product_name, product_version, product_binary, user_addr, user_locale, user_agent) ";
			$query.= "values ('$regist_day','$productName','$binaryVersion','$binaryName','$userAddr','$userlocale','$uaFullInfo')";

			$res = mysql_query($query, $conn);
		}
		mysql_close($conn);
	}

	//Testing
	//echo "$query";
	//exit();

	// Step4. Download Start
	header('Location: '.$productBinaryUrl);
}
else
{
	// Invalid configuration, Download failed -> Go Home.
	echo "<script> window.location.replace('/'); </script>";
	exit();
}

?>
